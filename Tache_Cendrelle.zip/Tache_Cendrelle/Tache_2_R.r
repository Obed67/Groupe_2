library(readr)
#library(ggplot2)

file_path <- "C:/Users/Mselle FAIZOUN/Documents/Housing.csv" 
housing_data <- readr::read_csv(file_path)
print(head(housing_data))
prices <- housing_data$price
areas <- housing_data$area
bedrooms <- housing_data$bedrooms

print("Prices:")
print(prices)
print("Areas:")
print(areas)
print("Bedrooms:")
print(bedrooms)

par(mfrow = c(2, 1))
plot(housing_data$area, housing_data$price, main = "Area vs Price", 
     xlab = "Area", ylab = "Price")
hist(housing_data$bedrooms, xlab = "Bedrooms", main = "Histogramme of bedrooms")

