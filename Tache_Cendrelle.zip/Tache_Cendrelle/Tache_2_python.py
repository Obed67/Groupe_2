import pandas as pd
import os
import matplotlib.pyplot as plt

file_path = r'C:/Users/Mselle FAIZOUN\Documents/Housing.csv'  
print(f"Chemin du fichier : {file_path}")
if os.path.exists(file_path):
    print("Le fichier existe.")
else:
    print("Le fichier n'existe pas. Vérifiez le chemin.")
try:
    housing_data = pd.read_csv(file_path)
    print("Fichier lu avec succès.")
    print(housing_data.head())
    prices = housing_data['price'].tolist()
    areas = housing_data['area'].tolist()
    bedrooms = housing_data['bedrooms'].tolist()
    #print("Prices:", prices)
    #print("Areas:", areas)
    #print("Bedrooms:", bedrooms)
    housing_data['price_per_area'] = housing_data['price'] / housing_data['area']
    print(housing_data[['price', 'area', 'price_per_area']].head())

except FileNotFoundError as e:
    print(f"Erreur : {e}")
except Exception as e:
    print(f"Une erreur s'est produite : {e}")
    
plt.figure()
plt.subplot(2, 1, 1)
plt.scatter(areas, prices, c=prices)
plt.title('Graphique de nuage de points')
plt.xlabel('Areas')
plt.ylabel('Prices')
plt.subplot(2, 1, 2)
plt.hist(bedrooms)
plt.title('Histogramme')
plt.show()